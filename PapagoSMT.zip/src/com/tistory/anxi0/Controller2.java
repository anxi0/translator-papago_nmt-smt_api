package com.tistory.anxi0;

import com.fasterxml.jackson.databind.ObjectMapper;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.scene.input.Clipboard;
import javafx.scene.input.ClipboardContent;

public class Controller2 implements Initializable {
    @FXML
    Button btn_nmt;
    @FXML
    Button btn_smt;
    @FXML
    ComboBox<String> combo_start;
    @FXML
    ComboBox<String> combo_end;
    @FXML
    TextArea txtarea_start;
    @FXML
    TextArea txtarea_end;
    @FXML
    Label lbl_copytext;

    HashMap<String,Object> end = new HashMap<>();

    String clientId = "gdEgvRX1u_V3i2Vg86JL";//애플리케이션 클라이언트 아이디값";
    String clientSecret = "g3evgQWfpJ";//애플리케이션 클라이언트 시크릿값";

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        end.put("한국어","ko");
        end.put("영어","en");
        end.put("중국어 간체","zh-CN");
        end.put("중국어 번체","zh-TW");
        end.put("스페인어","es");
        end.put("프랑스어","fr");
        end.put("베트남어","vi");
        end.put("태국어","th");
        end.put("인도네시아어","id");
        end.put("일본어","ja");
        end.put("독일어","de");
        end.put("러시아어","ru");
        end.put("이탈리아어","it");
        combo_start.getItems().addAll("한국어","영어","일본어","중국어 간체","중국어 번체","베트남어","인도네시아어","태국어","독일어","러시아어","스페인어","이탈리아어","프랑스어");
        combo_end.getItems().addAll("한국어","영어","일본어","중국어 간체","중국어 번체","베트남어","인도네시아어","태국어","독일어","러시아어","스페인어","이탈리아어","프랑스어");
        class Toolkit{

        }
    }
    private static String parseJson(String json) throws Exception {
        Map<String, Object> map = new ObjectMapper().readValue(json, Map.class);
        Map<String, Object> message = (Map<String, Object>) map.get("message");
        Map<String, String> result = (Map<String, String>) message.get("result");

        return result.get("translatedText");
    }
    public void Copy(){
        Clipboard clipboard = Clipboard.getSystemClipboard();
        ClipboardContent content = new ClipboardContent();
        content.putString(txtarea_end.getText());
        clipboard.setContent(content);
        lbl_copytext.setText("Text Copied");
    }
    public void NMT(ActionEvent event) throws IOException {
        try{
        lbl_copytext.setText("");
        txtarea_end.clear();
        String str=txtarea_start.getText();
        String URL="https://openapi.naver.com/v1/papago/n2mt";
        String index = send(URL, str);
        txtarea_end.appendText(parseJson(index));
        }catch(Exception e){
            e.printStackTrace();
            txtarea_end.appendText("지원하지 않는 언어입니다.");
        }

    }
    public void SMT(ActionEvent event) throws Exception {
       try{
        lbl_copytext.setText("");
        txtarea_end.clear();
        String str=txtarea_start.getText();
        String URL="https://openapi.naver.com/v1/language/translate";
        String index=send(URL,str);
        txtarea_end.appendText(parseJson(index));
    }catch(Exception e){
           txtarea_end.appendText("지원하지 않는 언어입니다.");
       }
    }

    public String send(String URL, String str){

        try {
            String text = URLEncoder.encode(str, "UTF-8");
            String apiURL = URL;
            URL url = new URL(apiURL);
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("POST");
            con.setRequestProperty("X-Naver-Client-Id", clientId);
            con.setRequestProperty("X-Naver-Client-Secret", clientSecret);

            String target= (String) end.get(combo_end.getValue());
            String target2= (String) end.get(combo_start.getValue());
            if(target==null){
                target="en";
            }
            if(target2==null){
                target2="ko";
            }
            String postParams = "source="+target2+"&target="+target+"&text=" + text;
            con.setDoOutput(true);
            DataOutputStream wr = new DataOutputStream(con.getOutputStream());
            wr.writeBytes(postParams);
            wr.flush();
            wr.close();
            int responseCode = con.getResponseCode();
            BufferedReader br;
            if (responseCode == 200) { // 정상 호출
                br = new BufferedReader(new InputStreamReader(con.getInputStream()));
            } else {  // 에러 발생
                br = new BufferedReader(new InputStreamReader(con.getErrorStream()));
            }
            String inputLine;
            StringBuffer response = new StringBuffer();
            while ((inputLine = br.readLine()) != null) {
                response.append(inputLine);
            }
            br.close();
                return response.toString();
            } catch (Exception e) {
            System.out.println(e);
        }
        return null;
    }

    public void Info(ActionEvent event){
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Wonderful Translator Developer");
        alert.setHeaderText("Thank you,");
        alert.setContentText("And you?");
        alert.showAndWait();

        Optional<ButtonType> result = alert.showAndWait();
        if(result.get() != ButtonType.OK)
        while (true){
            Infoalert("Why.","Why,","Why?");
        }
        else{
            Infoalert("WonderFul!","Thank you","And Bye.");
        }

    }
    public void Infoyesno(String one, String two, String three){
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle(one);
        alert.setHeaderText(two);
        alert.setContentText(three);
        alert.show();
    }
    public void Infoalert(String one, String two,String three){
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle(one);
        alert.setHeaderText(two);
        alert.setContentText(three);
        alert.show();
    }

}
