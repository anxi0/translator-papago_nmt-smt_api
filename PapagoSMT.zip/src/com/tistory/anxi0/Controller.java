package com.tistory.anxi0;

import com.fasterxml.jackson.databind.ObjectMapper;
import javafx.event.*;
import javafx.fxml.*;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.stage.*;

import java.io.*;



public class Controller {
    @FXML
    Button btn_main;

    public void onClicked(ActionEvent event) throws IOException {
        Stage stage = (Stage) btn_main.getScene().getWindow();
        FXMLLoader loader = new FXMLLoader(getClass().getResource("selectmenu.fxml"));
        Parent root = loader.load();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }


}
